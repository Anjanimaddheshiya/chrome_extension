
window.addEventListener('load', function() {
    console.log('All assets are loaded')
})

// const btn  = document.querySelector("#btn");

document.addEventListener("click",async ()=>{
let [tab] = await chrome.tabs.query({active:true,currentWindow:true});

chrome.scripting.executeScript({
target:{tabId:tab.id},
function:selectData,
},async (injectionResults)=>{
const [data] = injectionResults;
if(data.result){
    try{
await navigator.clipboard.writeText(data.result);
    }
    catch(error){
console.log("error == ",error);
    }
}
else{
    console.log("no data");
}
});
})

function selectData(){
    return document.getSelection().toString();
}


